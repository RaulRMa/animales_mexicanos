import sqlite3
import time
from sqlite3 import Error

animal = 1
db = 'animales.db'

def crea_conexion(db):
    """Crea una conexión con la base de datos SQLite"""
    con = None
    try:
        con = sqlite3.connect(db)
        print('Conexión creada correctamente!')
        return con
    except Error as e:
        print(e)
    return con


def crea_tabla(conexion):
    crea_tabla = """CREATE TABLE Animales (
        id integer PRIMARY KEY AUTOINCREMENT,
        nombre varchar,
        descripcion text,
        nombre_cientifico varchar,
        tipo varchar,
        imagen blob
        ); """
    try:
        c = conexion.cursor()
        c.execute(crea_tabla)
    except Error as e:
        print(e)

def obten_informacion(animal,db):
    con = crea_conexion(db)
    query = """SELECT * from animales WHERE id = ?"""
    cur = con.cursor()
    result = cur.execute(query,(animal,))
    result = result.fetchone()
    print("Datos recuperados!")
    
    ejemplar = {
        "nombre": result[1],
        "descripcion": ("No registrado", result[2])[result[2] != None],
        "nombreCientifico": ("No registrado", result[3])[result[3] != None],
        "tipo": ("No registrado", result[4])[result[4] != None],
        "imagen": (None, result[5])[result[5] != None]
    }
    return ejemplar

obten_informacion(animal,db)